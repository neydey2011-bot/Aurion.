require("dotenv").config();
const express = require("express");
const session = require("express-session");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const bcrypt = require("bcryptjs");
const Database = require("better-sqlite3");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = process.env.PORT || 3000;
const dbFile = process.env.DB_FILE || "./data/aurion.db";
fs.mkdirSync(path.dirname(path.resolve(dbFile)), { recursive: true });
const db = new Database(dbFile);
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 email TEXT NOT NULL UNIQUE,
 password_hash TEXT NOT NULL,
 role TEXT NOT NULL DEFAULT 'partner',
 approved INTEGER NOT NULL DEFAULT 0,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS products (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 partner_id INTEGER,
 title TEXT NOT NULL,
 description TEXT NOT NULL DEFAULT '',
 price_cents INTEGER NOT NULL,
 image_url TEXT NOT NULL DEFAULT '',
 stock INTEGER,
 active INTEGER NOT NULL DEFAULT 0,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(partner_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS coupons (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 code TEXT NOT NULL UNIQUE,
 discount_percent INTEGER NOT NULL,
 max_uses INTEGER NOT NULL,
 used_count INTEGER NOT NULL DEFAULT 0,
 active INTEGER NOT NULL DEFAULT 1,
 expires_at TEXT
);
CREATE TABLE IF NOT EXISTS coupon_uses (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 coupon_id INTEGER NOT NULL,
 customer_email TEXT NOT NULL,
 order_id INTEGER,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE(coupon_id, customer_email),
 FOREIGN KEY(coupon_id) REFERENCES coupons(id)
);
CREATE TABLE IF NOT EXISTS orders (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 customer_name TEXT NOT NULL,
 customer_email TEXT NOT NULL,
 customer_phone TEXT NOT NULL,
 address TEXT NOT NULL,
 subtotal_cents INTEGER NOT NULL,
 discount_cents INTEGER NOT NULL DEFAULT 0,
 total_cents INTEGER NOT NULL,
 coupon_id INTEGER,
 status TEXT NOT NULL DEFAULT 'pending',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(coupon_id) REFERENCES coupons(id)
);
CREATE TABLE IF NOT EXISTS order_items (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 order_id INTEGER NOT NULL,
 product_id INTEGER NOT NULL,
 product_title TEXT NOT NULL,
 quantity INTEGER NOT NULL,
 unit_price_cents INTEGER NOT NULL,
 FOREIGN KEY(order_id) REFERENCES orders(id),
 FOREIGN KEY(product_id) REFERENCES products(id)
);
`);

const adminEmail = (process.env.ADMIN_EMAIL || "").trim().toLowerCase();
const adminPassword = process.env.ADMIN_PASSWORD || "";
if (adminEmail && adminPassword) {
  const existing = db.prepare("SELECT id FROM users WHERE email=?").get(adminEmail);
  if (!existing) {
    const hash = bcrypt.hashSync(adminPassword, 12);
    db.prepare("INSERT INTO users(name,email,password_hash,role,approved) VALUES(?,?,?,?,1)")
      .run("Administrador AURION", adminEmail, hash, "admin");
  }
}

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "100kb" }));
app.use(express.urlencoded({ extended: false }));
app.use(session({
  secret: process.env.SESSION_SECRET || "development-only-change-me",
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", maxAge: 1000*60*60*8 }
}));
app.use(express.static(path.join(__dirname, "public")));
const limiter = rateLimit({ windowMs: 15*60*1000, limit: 100 });
app.use("/api", limiter);

const money = n => Math.round(Number(n) * 100);
const clean = v => String(v || "").trim();
const isEmail = v => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
const requireAdmin = (req,res,next) => {
  if (!req.session.user || req.session.user.role !== "admin") return res.status(401).json({error:"Acesso administrativo necessário."});
  next();
};
const requirePartner = (req,res,next) => {
  if (!req.session.user || !["partner","admin"].includes(req.session.user.role)) return res.status(401).json({error:"Entre na sua conta."});
  if (req.session.user.role === "partner" && !req.session.user.approved) return res.status(403).json({error:"Sua conta ainda aguarda aprovação."});
  next();
};

app.get("/api/products", (req,res) => {
  const rows = db.prepare(`SELECT p.id,p.title,p.description,p.price_cents,p.image_url,p.stock,u.name partner_name
    FROM products p LEFT JOIN users u ON u.id=p.partner_id
    WHERE p.active=1 AND (p.stock IS NULL OR p.stock>0) ORDER BY p.id DESC`).all();
  res.json(rows.map(p=>({...p,price:p.price_cents/100})));
});

app.post("/api/partners/register", async (req,res) => {
  const name=clean(req.body.name), email=clean(req.body.email).toLowerCase(), password=String(req.body.password||"");
  if (!name || !isEmail(email) || password.length<8) return res.status(400).json({error:"Informe nome, e-mail válido e senha com pelo menos 8 caracteres."});
  try {
    const hash=await bcrypt.hash(password,12);
    db.prepare("INSERT INTO users(name,email,password_hash,role,approved) VALUES(?,?,?,?,0)").run(name,email,hash,"partner");
    res.status(201).json({message:"Cadastro enviado. Aguarde a aprovação da AURION."});
  } catch { res.status(409).json({error:"Este e-mail já está cadastrado."}); }
});

app.post("/api/login", async (req,res) => {
  const email=clean(req.body.email).toLowerCase(), password=String(req.body.password||"");
  const user=db.prepare("SELECT * FROM users WHERE email=?").get(email);
  if (!user || !(await bcrypt.compare(password,user.password_hash))) return res.status(401).json({error:"E-mail ou senha incorretos."});
  req.session.user={id:user.id,name:user.name,email:user.email,role:user.role,approved:!!user.approved};
  res.json({user:req.session.user});
});
app.post("/api/logout",(req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get("/api/me",(req,res)=>res.json({user:req.session.user||null}));

app.post("/api/partner/products",requirePartner,(req,res)=>{
  const title=clean(req.body.title), description=clean(req.body.description), image=clean(req.body.image_url);
  const price=Number(req.body.price), stockRaw=req.body.stock;
  const stock=stockRaw==="" || stockRaw===null || stockRaw===undefined ? null : Number(stockRaw);
  if(!title || !Number.isFinite(price) || price<=0 || (stock!==null && (!Number.isInteger(stock)||stock<0))) return res.status(400).json({error:"Confira nome, preço e estoque."});
  const result=db.prepare("INSERT INTO products(partner_id,title,description,price_cents,image_url,stock,active) VALUES(?,?,?,?,?,?,?)")
    .run(req.session.user.id,title,description,money(price),image,stock,req.session.user.role==="admin"?1:0);
  res.status(201).json({id:result.lastInsertRowid,message:req.session.user.role==="admin"?"Produto publicado.":"Produto enviado para aprovação."});
});

app.post("/api/coupons/validate",(req,res)=>{
  const code=clean(req.body.code).toUpperCase(), email=clean(req.body.email).toLowerCase();
  const c=db.prepare("SELECT * FROM coupons WHERE code=? AND active=1").get(code);
  if(!c || c.used_count>=c.max_uses || (c.expires_at && new Date(c.expires_at)<new Date())) return res.status(400).json({error:"Cupom inválido, expirado ou esgotado."});
  if(!isEmail(email)) return res.status(400).json({error:"Informe seu e-mail para verificar o cupom."});
  const used=db.prepare("SELECT id FROM coupon_uses WHERE coupon_id=? AND customer_email=?").get(c.id,email);
  if(used) return res.status(409).json({error:"Este e-mail já utilizou esse cupom."});
  res.json({code:c.code,discount_percent:c.discount_percent,remaining:c.max_uses-c.used_count});
});

app.post("/api/orders",(req,res)=>{
  const {name,email,phone,address,items,couponCode}=req.body;
  if(!clean(name)||!isEmail(clean(email))||!clean(phone)||!clean(address)||!Array.isArray(items)||!items.length) return res.status(400).json({error:"Preencha seus dados e adicione produtos."});
  if(items.length>30) return res.status(400).json({error:"Limite de 30 produtos diferentes por pedido."});
  const getProduct=db.prepare("SELECT id,title,price_cents,stock FROM products WHERE id=? AND active=1");
  let subtotal=0, normalized=[];
  for(const item of items){
    const p=getProduct.get(Number(item.id)), qty=Number(item.quantity);
    if(!p||!Number.isInteger(qty)||qty<1||qty>20) return res.status(400).json({error:"Produto ou quantidade inválida."});
    if(p.stock!==null && p.stock<qty) return res.status(400).json({error:`Estoque insuficiente para ${p.title}.`});
    subtotal+=p.price_cents*qty; normalized.push({p,qty});
  }
  let coupon=null, discount=0;
  if(clean(couponCode)){
    coupon=db.prepare("SELECT * FROM coupons WHERE code=? AND active=1").get(clean(couponCode).toUpperCase());
    if(!coupon||coupon.used_count>=coupon.max_uses||(coupon.expires_at&&new Date(coupon.expires_at)<new Date())) return res.status(400).json({error:"Cupom inválido ou esgotado."});
    if(db.prepare("SELECT id FROM coupon_uses WHERE coupon_id=? AND customer_email=?").get(coupon.id,clean(email).toLowerCase())) return res.status(409).json({error:"Este e-mail já utilizou esse cupom."});
    discount=Math.floor(subtotal*coupon.discount_percent/100);
  }
  const create=db.transaction(()=>{
    const order=db.prepare("INSERT INTO orders(customer_name,customer_email,customer_phone,address,subtotal_cents,discount_cents,total_cents,coupon_id) VALUES(?,?,?,?,?,?,?,?)")
      .run(clean(name),clean(email).toLowerCase(),clean(phone),clean(address),subtotal,discount,subtotal-discount,coupon?coupon.id:null);
    const orderId=order.lastInsertRowid;
    const addItem=db.prepare("INSERT INTO order_items(order_id,product_id,product_title,quantity,unit_price_cents) VALUES(?,?,?,?,?)");
    const reduceStock=db.prepare("UPDATE products SET stock=stock-? WHERE id=? AND stock IS NOT NULL");
    normalized.forEach(({p,qty})=>{addItem.run(orderId,p.id,p.title,qty,p.price_cents);reduceStock.run(qty,p.id);});
    if(coupon){
      db.prepare("INSERT INTO coupon_uses(coupon_id,customer_email,order_id) VALUES(?,?,?)").run(coupon.id,clean(email).toLowerCase(),orderId);
      db.prepare("UPDATE coupons SET used_count=used_count+1,active=CASE WHEN used_count+1>=max_uses THEN 0 ELSE active END WHERE id=?").run(coupon.id);
    }
    return orderId;
  });
  const orderId=create();
  res.status(201).json({orderId,total:(subtotal-discount)/100,discount:discount/100,message:"Pedido registrado! A loja precisa confirmar pagamento e entrega com você."});
});

app.post("/api/admin/login-info",requireAdmin,(req,res)=>res.json({user:req.session.user}));
app.get("/api/admin/overview",requireAdmin,(req,res)=>{
  res.json({
    partners:db.prepare("SELECT id,name,email,approved,created_at FROM users WHERE role='partner' ORDER BY id DESC").all(),
    products:db.prepare("SELECT p.*,u.name partner_name FROM products p LEFT JOIN users u ON u.id=p.partner_id ORDER BY p.id DESC").all(),
    coupons:db.prepare("SELECT * FROM coupons ORDER BY id DESC").all(),
    orders:db.prepare("SELECT * FROM orders ORDER BY id DESC LIMIT 100").all()
  });
});
app.post("/api/admin/partners/:id/approve",requireAdmin,(req,res)=>{
  const r=db.prepare("UPDATE users SET approved=1 WHERE id=? AND role='partner'").run(Number(req.params.id));
  res.json({ok:r.changes>0});
});
app.post("/api/admin/products/:id/approve",requireAdmin,(req,res)=>{
  const r=db.prepare("UPDATE products SET active=1 WHERE id=?").run(Number(req.params.id));
  res.json({ok:r.changes>0});
});
app.post("/api/admin/coupons",requireAdmin,(req,res)=>{
  const code=clean(req.body.code).toUpperCase(), discount=Number(req.body.discount_percent), max=Number(req.body.max_uses), expires=clean(req.body.expires_at)||null;
  if(!/^[A-Z0-9_-]{3,24}$/.test(code)||!Number.isInteger(discount)||discount<1||discount>90||!Number.isInteger(max)||max<1||max>100000) return res.status(400).json({error:"Código, desconto ou limite inválido."});
  try{
    db.prepare("INSERT INTO coupons(code,discount_percent,max_uses,expires_at) VALUES(?,?,?,?)").run(code,discount,max,expires);
    res.status(201).json({message:"Cupom criado."});
  }catch{res.status(409).json({error:"Esse código já existe."});}
});
app.patch("/api/admin/coupons/:id/toggle",requireAdmin,(req,res)=>{
  const c=db.prepare("SELECT active FROM coupons WHERE id=?").get(Number(req.params.id));
  if(!c)return res.status(404).json({error:"Cupom não encontrado."});
  db.prepare("UPDATE coupons SET active=? WHERE id=?").run(c.active?0:1,Number(req.params.id));
  res.json({ok:true});
});
app.patch("/api/admin/orders/:id/status",requireAdmin,(req,res)=>{
  const allowed=["pending","paid","shipped","completed","cancelled"];
  if(!allowed.includes(req.body.status))return res.status(400).json({error:"Status inválido."});
  db.prepare("UPDATE orders SET status=? WHERE id=?").run(req.body.status,Number(req.params.id));
  res.json({ok:true});
});

app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(PORT,()=>console.log(`AURION rodando na porta ${PORT}`));
