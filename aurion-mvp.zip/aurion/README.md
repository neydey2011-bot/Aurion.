# AURION — MVP de marketplace

Projeto inicial funcional de loja virtual com vitrine, cadastro de parceiros, aprovação administrativa, pedidos e cupons de uso único por e-mail.

## Requisitos
- Node.js 20 ou superior
- npm

## Rodar no computador
1. Copie `.env.example` para `.env`.
2. Preencha `SESSION_SECRET`, `ADMIN_EMAIL` e `ADMIN_PASSWORD` com valores fortes.
3. Execute `npm install`.
4. Execute `npm start`.
5. Abra `http://localhost:3000`.

## Publicar no Render
1. Crie um repositório GitHub e envie os arquivos deste projeto.
2. No Render, crie um Web Service conectado ao repositório.
3. Use `npm install` como Build Command e `npm start` como Start Command.
4. Configure `ADMIN_EMAIL` e `ADMIN_PASSWORD` como variáveis secretas.
5. O `render.yaml` configura um disco persistente em `/var/data`.

## Importante antes de vender
- Este é um MVP inicial, não uma plataforma pronta para receber pagamentos automaticamente.
- O checkout registra o pedido como pendente. Integre um gateway (por exemplo, Mercado Pago) e valide notificações/webhooks no servidor antes de marcar pedidos como pagos.
- A regra de cupom limita a uma utilização por e-mail. Para impedir abuso por pessoas que usem vários e-mails, será necessário autenticar clientes e definir uma política de identificação adicional.
- A tela de administração deste MVP mostra os dados e cria cupons; aprovação de parceiros/produtos e atualização de pedidos estão disponíveis pelas rotas da API, mas ainda precisam de botões na interface administrativa.
- Adicione termos de uso, política de privacidade, política de troca/devolução, dados empresariais e regras de comissão.
- Não publique senhas reais no GitHub. Use variáveis de ambiente.
- Para operar com fornecedores, obtenha autorização por escrito para imagens, preços, estoque, entrega e comissão.
- Pagamentos, contratos e dados financeiros devem ser configurados com apoio de um responsável adulto, se necessário.

## Rotas principais
- `GET /api/products`
- `POST /api/partners/register`
- `POST /api/login`
- `POST /api/partner/products`
- `POST /api/coupons/validate`
- `POST /api/orders`
- `GET /api/admin/overview`
- `POST /api/admin/coupons`

Este projeto é a base para desenvolvimento e testes. Faça revisão de segurança e testes antes de receber pedidos reais.
